%% Berken Utku Demirel - 2166221 - Ibrahim Duru - 2166304
clear 
clc
close all
%% Add path to LPC coder functions
addpath('C:\Users\berkenutku\Desktop\DSP-HW\LPC encoderdecoder matlab files-20191206');
[y,Fs] = audioread('430_dnm.wav');
LPC_output = LPC_tx_s(y); %pitch_plot is pitch periods
LPC_output = LPC_output.'; %
% y2=de2bi(y,8).';
% y3 = y2(:);
% k = udecode(y,8);
%% LPC output to -1 1
LPC_output = int16(LPC_output);
LPC_output(LPC_output == 0) = -1; 
LPC_output = y3.';
%% Preamble Addition
bits_to_preamble = [1 -1 1 -1 1 -1 1 -1]; %Preamble bit sequence

Preamble_output = [bits_to_preamble LPC_output];
%% Arrange bit duration
Ts =.005; %5 ms              
%% Modulation
L = 100; % Samples for each symbol
Fs = 1/Ts; %Sampling rate of symbols                                         
f1 = 6 * Fs; %Carrier frequency for high bit                       
f2 = 2 * Fs; %Carrier frequenct for low bit                         
t2 = Ts/L:Ts/L:Ts;                 
modulation_output = [];
for (i=1:1:length(Preamble_output))
    if (Preamble_output(i) == 1)
        y = cos(2*pi*f1*t2);
    else
        y = cos(2*pi*f2*t2);
    end
    modulation_output = [modulation_output y];
end
%% ----- Demodulation -----
output_bits = [];

    f1 = Fs;  % cuttoff low frequency 
    f2 = 3 * Fs; % cuttoff high frequency 
    Wn = [f1 f2] * 2 / (L * Fs) ;
    N = 4;     
    [b_low, a_low] = butter(N,Wn,'bandpass');
    f1 = 5 * Fs;  
    f2 = 7 * Fs; 
    Wn = [f1 f2] * 2 / (L * Fs) ;
    N = 4;     
    [b_high, a_high] = butter(N,Wn,'bandpass');

for n = length(t2):length(t2):length(modulation_output)
    signal_section = modulation_output(n - L+1:n);
    high_check = std(filter(b_high,a_high,signal_section));
    low_check = std(filter(b_low, a_low, signal_section));
    
    if( high_check > 0.45)
        bit = 1;
    else
        bit = 0;
    end
        
output_bits(end+1) = bit;
end
%% Preamble check
t = 0; %Preamble sequence finish index
for a = 1:(length(output_bits) - 7)
    if (output_bits(a:a+7) == [1 0 1 0 1 0 1 0]) %Check whether preamble is in received bits.
        t = a+7;
        break;
    end
end

output_bits = output_bits(t+1:end);

synth_speech_2 = LPC_rx_s(output_bits.');

[number,ratio] = biterr(uint16(output_bits),uint16(LPC_output));

fprintf('Total number of bit to transmit:%d \n',length(LPC_output));
fprintf("Number of incorrect bit:%d \n",ratio);


