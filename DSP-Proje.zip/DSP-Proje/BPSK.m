%% Berken Utku Demirel - 2166221 - Ibrahim Duru - 2166304
%% Add path to LPC coder functions
addpath('C:\Users\berkenutku\Desktop\DSP-HW\LPC encoderdecoder matlab files-20191206');
load('s_n_for_BPSK.mat'); % Load transmitted part of preamble part for demodulation
[y,Fs] = audioread('430_dnm.wav');
LPC_output = LPC_tx_s(y);  %pitch_plot is pitch periods
LPC_output = LPC_output.';
%% LPC output to -1 1
LPC_output = int16(LPC_output);
LPC_output(LPC_output == 0) = -1; 
%% Preamble Addition
bits_to_preamble = [1 -1 1 -1 1 -1 1 -1]; %Preamble bit sequence

Preamble_output = [bits_to_preamble LPC_output];
%% Upsampling
L = 20;

Upsampling_output = upsample(Preamble_output,L);
%% Tx Filter(RRC)
beta = 0.5;
span = 10;
p_n = rcosdesign(beta,span,L);

RRC_output = conv(p_n,Upsampling_output);
%% Multiply by carrier 
fc = 6000; %Carrier frequency
fs = 20 * 1200;
t1 = 1/fs:1/fs:(1/fs)* length(RRC_output);

output_of_carrier = RRC_output .* cos(2* pi * fc * t1);
%% ----------- Demodulation part ----------

%% Preamble demodulation
s_n_flip = fliplr(s_n(2:360));
s_n_flip = [s_n_flip(1) s_n_flip];

filter_output_preamble = (conv(s_n_flip,output_of_carrier)).';

[M,I] = max(filter_output_preamble); % In real time there should be threshold to check M value whether sequence starts or not
I = I - (L * span / 2) -1; % When time index is determined, the zeros which at the beginnig of the sequence should be discard.
obtained_data = output_of_carrier(I:end);
%% Multiplying by cosine
t1_modify = t1(I:end);
output_of_cosine_multiply = obtained_data .* cos(2* pi * fc * t1_modify);

% Apply low-pass filter
fc = 7000;
[b,a] = butter(6,fc/(fs/2));
output_of_low_pass = filter(b,a,output_of_cosine_multiply);
%% Matched filter
matched_filter = fliplr(p_n);

matched_filter_output = conv(matched_filter.',output_of_low_pass);
%% Downsampling
downsampling_output = downsample(matched_filter_output,L);
%% Detector
Detector_output = downsampling_output((span/2)+1:length(downsampling_output) - span - 1);
Detector_output(Detector_output < 0) = 0;
Detector_output(Detector_output > 0) = 1;
%% LPC decoder
Detector_output(2) = 1;
synth_speech_2 = LPC_rx_s(Detector_output.');
tic
soundsc(synth_speech_2,8000);
toc
%% Bit error rate Computation

[number,ratio] = biterr(Detector_output,uint8(LPC_output));

fprintf('Total number of bit to transmit:%d \n',length(LPC_output));
fprintf("Number of incorrect bit:%d \n",ratio);

