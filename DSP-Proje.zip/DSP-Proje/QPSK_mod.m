function QPSK_mod(data, sampling_rate)

LPC_output = LPC_tx_s(data); %pitch_plot is pitch periods
%% LPC output to -1 1
LPC_output = int16(LPC_output.');
LPC_output(LPC_output == 0) = -1;
%% Divide bits
In_phase_bits = LPC_output(1:2:end);
Quad_mod_bits = LPC_output(2:2:end);
%% ------ Modulators -----
%Up samplling 
L = 20;
% Tx Filter(RRC)
beta = 0.5;
span = 10;
p_n = rcosdesign(beta,span,L);
%% In-phase modulator
In_phase_upsample = upsample(In_phase_bits,L);
% RRC filter
In_phase_RRC_filter_output = conv(In_phase_upsample,p_n);

% Carrier multiplication
fc = 6000; %Carrier frequency
fs = L * 1200;
t1 = 1/fs:1/fs:(1/fs)* length(In_phase_RRC_filter_output);

output_of_In_phase_carrier = In_phase_RRC_filter_output .* cos(2* pi * fc * t1);
%% Quadrature modulator
Quad_mod_upsample = upsample(Quad_mod_bits,L);
% RRC filter
Quad_phase_RRC_filter_output = conv(Quad_mod_upsample,p_n);

%Carrier multiplication
output_of_Quad_mod_carrier = Quad_phase_RRC_filter_output .* sin(2 * pi * fc * t1);
%% Sum operation
output_of_sum = output_of_Quad_mod_carrier + output_of_In_phase_carrier;
%% Add preamble
bits_to_preamble = [1 -1 1 -1 1 -1 1 -1];
% Upsampling
Upsample_preamble_output = upsample(bits_to_preamble,L);
% RRC filter
Preamble_RRC_filter_output = conv(Upsample_preamble_output,p_n);
% Carrier multiplication
t1_preamble = 1/fs:1/fs:(1/fs)* length(Preamble_RRC_filter_output);

Preamble_output = Preamble_RRC_filter_output .* cos(2 * pi * fc * t1_preamble);

output_of_preamble = [Preamble_output output_of_sum];

soundsc(output_of_preamble, 44100);

end