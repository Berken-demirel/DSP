function helper_continuous_fft(data, Fs, real_Fs, plotHandle, lowpass_filter, modulation_type)

down_sample_rate = real_Fs / Fs;
data = downsample(data, down_sample_rate);

data = filter(lowpass_filter,1,data);

helper_filtered_fft(data, Fs, plotHandle);

tic 
switch (modulation_type)
    case 0
        FSK_mod(data, Fs);
    case 1
        BPSK_mod(data, Fs);
    case 2
        QPSK_mod(data, Fs);
    otherwise
        disp('Wrong Modulation Type')
end
toc

end