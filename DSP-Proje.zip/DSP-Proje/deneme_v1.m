%% Berken Utku Demirel - Samsa - 2166221
clear 
clc
close all
%% Add path to LPC coder functions
addpath('C:\Users\berkenutku\Desktop\DSP-HW\LPC encoderdecoder matlab files-20191206');
load('s_n_for_QPSK.mat');
[y,Fs] = audioread('430_dnm.wav');
%LPC_output = LPC_tx_s(y);
y1 = uencode(y,8);
y2 = de2bi(y1,8).';
y3 = y2(:);
LPC_output = y3;
% k = udecode(y,8);
%% LPC output to -1 1
LPC_output = int16(LPC_output.');
LPC_output(LPC_output == 0) = -1;
%% Divide bits
In_phase_bits = LPC_output(1:2:end);
Quad_mod_bits = LPC_output(2:2:end);
%% ------ Modulators -----
%Up samplling 
L = 20;
% Tx Filter(RRC)
beta = 0.5;
span = 10;
p_n = rcosdesign(beta,span,L);
%% In-phase modulator
In_phase_upsample = upsample(In_phase_bits,L);
% RRC filter
In_phase_RRC_filter_output = conv(In_phase_upsample,p_n);

% Carrier multiplication
fc = 6000; %Carrier frequency
fs = L * 1200;
t1 = 1/fs:1/fs:(1/fs)* length(In_phase_RRC_filter_output);

output_of_In_phase_carrier = In_phase_RRC_filter_output .* cos(2* pi * fc * t1);
%% Quadrature modulator
Quad_mod_upsample = upsample(Quad_mod_bits,L);
% RRC filter
Quad_phase_RRC_filter_output = conv(Quad_mod_upsample,p_n);

%Carrier multiplication
output_of_Quad_mod_carrier = Quad_phase_RRC_filter_output .* sin(2 * pi * fc * t1);
%% Sum operation
output_of_sum = output_of_Quad_mod_carrier + output_of_In_phase_carrier;
%% Add preamble
bits_to_preamble = [1 -1 1 -1 1 -1 1 -1 1 -1];
% Upsampling
Upsample_preamble_output = upsample(bits_to_preamble,L);
% RRC filter
Preamble_RRC_filter_output = conv(Upsample_preamble_output,p_n);
% Carrier multiplication
t1_preamble = 1/fs:1/fs:(1/fs)* length(Preamble_RRC_filter_output);

Preamble_output = Preamble_RRC_filter_output .* cos(2 * pi * fc * t1_preamble);

output_of_preamble = [Preamble_output output_of_sum];
%% ----------- Demodulation part ----------

%% Preamble demodulation
s_n_flip = fliplr(s_n(2:360));
s_n_flip = [s_n_flip(1) s_n_flip];

% Take correlation with s[-n] and output
filter_output_preamble = (conv(s_n_flip,output_of_preamble)).';

I = find(filter_output_preamble(1:500)>3.5); % The threshold value for determining the index of preamble (The part-2 of project is not real implementation so find is just looking first 500 index)
%Obtain data part
obtained_data = output_of_preamble(I:end);
%% Multiplying by cosine and sine
t_modify =  1/fs:1/fs:(1/fs)* length(obtained_data);
output_of_cosine_multiply = obtained_data .* cos(2* pi * fc * t_modify);
output_of_sine_multiply = obtained_data .* sin(2 * pi * fc * t_modify);
%% Apply low-pass filter
fc = 6000;
[b,a] = butter(6,fc/(fs/2));
output_of_low_pass_In_phase = filter(b,a,output_of_cosine_multiply);
output_of_low_pass_Quad_dem = filter(b,a,output_of_sine_multiply);
%% Matched filter
matched_filter = fliplr(p_n);

matched_filter_In_phase_output = conv(matched_filter.',output_of_low_pass_In_phase);
matched_filter_Quad_demo_output = conv(matched_filter.',output_of_low_pass_Quad_dem);

%% Downsampling
In_phase_down = downsample(matched_filter_In_phase_output,L);
Quad_demo_down = downsample(matched_filter_Quad_demo_output,L);
%% Detector
Detector_In_phase_output = In_phase_down;
Detector_In_phase_output(Detector_In_phase_output < 0) = 0;
Detector_In_phase_output(Detector_In_phase_output > 0) = 1;

Detector_Quad_demo_output = Quad_demo_down;
Detector_Quad_demo_output(Detector_Quad_demo_output < 0) = 0;
Detector_Quad_demo_output(Detector_Quad_demo_output > 0) = 1;
%% Combine bits
Combined_bits = [Detector_In_phase_output; Detector_Quad_demo_output];
Combined_bits = Combined_bits(:).';
Combined_bits = uint16(Combined_bits(L+1:length(Combined_bits)-L));
%% LPC decoder
synth_speech_agr = LPC_rx_s(Combined_bits.');
%% Bit error rate
[number,ratio] = biterr(Combined_bits,uint16(LPC_output));

fprintf('Total number of bit to transmit:%d \n',length(LPC_output));
fprintf("Number of incorrect bit:%d \n",ratio);