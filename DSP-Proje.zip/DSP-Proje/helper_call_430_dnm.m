function helper_call_430_dnm(data, Fs, modulation_type)



switch (modulation_type)
    case 0
        FSK_mod(data, Fs);
    case 1
        BPSK_mod(data, Fs);
    case 2
        QPSK_mod(data, Fs);
    otherwise
        disp('Wrong Modulation Type')
end


end