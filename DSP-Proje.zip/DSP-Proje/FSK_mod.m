function FSK_mod(data, sampling_rate)

LPC_output = LPC_tx_s(data); %pitch_plot is pitch periods
%% LPC output to -1 1
LPC_output = int16(LPC_output.');
LPC_output(LPC_output == 0) = -1; 
%% Preamble Addition
bits_to_preamble = [1 1 1 1 1 1 1 1]; %Preamble bit sequence

Preamble_output = [bits_to_preamble LPC_output];
%% Arrange bit duration
Ts =.001; %1 ms              
%% Modulation
L = 100; % Samples for each symbol
Fs = 1/Ts; %Sampling rate of symbols                                         
f1 = 6 * Fs; %Carrier frequency for high bit                       
f2 = 2 * Fs; %Carrier frequenct for low bit                         
t2 = Ts/L:Ts/L:Ts;                 

for i=1:1:length(Preamble_output)
    if (Preamble_output(i) == 1)
        y = cos(2*pi*f1*t2);
    else
        y = cos(2*pi*f2*t2);
    end
    sound(y, 44100);
end

end