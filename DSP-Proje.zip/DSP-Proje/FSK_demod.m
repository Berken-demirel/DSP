%% ----- Demodulation -----
function FSK_demod(modulation_output)

output_bits = [];
Ts =.005; %5 ms              
L = 100; % Samples for each symbol
Fs = 1/Ts; 
f1 = Fs;  % cuttoff low frequency
f2 = 3 * Fs; % cuttoff high frequency
Wn = [f1 f2] * 2 / (L * Fs) ;
N = 4;
[b_low, a_low] = butter(N,Wn,'bandpass');
f1 = 5 * Fs;
f2 = 7 * Fs;
Wn = [f1 f2] * 2 / (L * Fs) ;
N = 4;
[b_high, a_high] = butter(N,Wn,'bandpass');
t2 = Ts/L:Ts/L:Ts;  
for n = length(t2):length(t2):length(modulation_output)
    signal_section = modulation_output(n - L+1:n);

    high_check = std(filter(b_high,a_high,signal_section));
    low_check = std(filter(b_low, a_low, signal_section));
    
    if( high_check > 0.002)
        bit = 1;
    else
        bit = 0;
    end
        
output_bits(end+1) = bit;
end
%% Preamble check
t = 0; %Preamble sequence finish index
for a = 1:(length(output_bits) - 7)
    if (output_bits(a:a+7) == [1 0 1 0 1 0 1 0]) %Check whether preamble is in received bits.
        t = a+7;
        break;
    end
end

end
