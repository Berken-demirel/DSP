%% ----------- Demodulation part ----------
function BPSK_demod(output_of_carrier, fs, Preamble_detector)
%% Preamble demodulation
Preamble_detector.Threshold = 2;
output_of_preamble = output_of_carrier(:,1);
[idx,detmet] = Preamble_detector(output_of_preamble);
obtained_data = output_of_carrier(idx:end);
if (isempty(idx))
    return
end
%% Multiplying by cosine
t1_modify = t1(I:end);
output_of_cosine_multiply = obtained_data .* cos(2* pi * fc * t1_modify);

% Apply low-pass filter
fc = 7000;
[b,a] = butter(6,fc/(fs/2));
output_of_low_pass = filter(b,a,output_of_cosine_multiply);
%% Matched filter
matched_filter = fliplr(p_n);

matched_filter_output = conv(matched_filter.',output_of_low_pass);
%% Downsampling
downsampling_output = downsample(matched_filter_output,L);
%% Detector
Detector_output = downsampling_output((span/2)+1:length(downsampling_output) - span - 1);
Detector_output(Detector_output < 0) = 0;
Detector_output(Detector_output > 0) = 1;
%% LPC decoder
try
    synth_speech = LPC_tx_s(Detector_output.');
catch 
    disp("Wrong LPC");
    synth_speech = 0;
end
soundsc(synth_speech, 8000);
end

