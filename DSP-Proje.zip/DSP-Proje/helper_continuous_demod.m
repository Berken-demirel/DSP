function helper_continuous_demod(data, Fs, real_Fs, modulation_type, preamble)

down_sample_rate = real_Fs / Fs;
data = downsample(data, down_sample_rate);

switch (modulation_type)
    case 0
        FSK_demod(data);
    case 1
        BPSK_demod(data, Fs, preamble);
    case 2
        QPSK_demod(data, preamble);
    otherwise
        disp('Wrong Modulation Type')
end

end