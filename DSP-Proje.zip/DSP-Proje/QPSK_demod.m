%% Berken Utku Demirel - Samsa - 2166221
%% ----------- Demodulation part ----------
function QPSK_demod(output_of_preamble, Preamble_detector)
% % Preamble demodulation
Preamble_detector.Threshold = 2;
output_of_preamble = output_of_preamble(:,1);
[idx,detmet] = Preamble_detector(output_of_preamble);

if (isempty(idx))
    return
end
%% Obtain data part
output_of_preamble(idx:end);
fc = 6000;
fs = 20 * 1200;
L = 20;
% Tx Filter(RRC)
beta = 0.5;
span = 10;
p_n = rcosdesign(beta,span,L);
%
obtained_data = output_of_preamble(:,1).';
%% Multiplying by cosine and sine
t_modify =  1/fs:1/fs:(1/fs)* length(obtained_data);
output_of_cosine_multiply = obtained_data .* cos(2* pi * fc * t_modify);
output_of_sine_multiply = obtained_data .* sin(2 * pi * fc * t_modify);
%% Apply low-pass filter
fc = 6000;
[b,a] = butter(6,fc/(fs/2));
output_of_low_pass_In_phase = filter(b,a,output_of_cosine_multiply);
output_of_low_pass_Quad_dem = filter(b,a,output_of_sine_multiply);
%% Matched filter
matched_filter = fliplr(p_n);

matched_filter_In_phase_output = conv(matched_filter.',output_of_low_pass_In_phase);
matched_filter_Quad_demo_output = conv(matched_filter.',output_of_low_pass_Quad_dem);

%% Downsampling
In_phase_down = downsample(matched_filter_In_phase_output,L);
Quad_demo_down = downsample(matched_filter_Quad_demo_output,L);
%% Detector
Detector_In_phase_output = In_phase_down;
Detector_In_phase_output(Detector_In_phase_output < 0) = 0;
Detector_In_phase_output(Detector_In_phase_output > 0) = 1;

Detector_Quad_demo_output = Quad_demo_down;
Detector_Quad_demo_output(Detector_Quad_demo_output < 0) = 0;
Detector_Quad_demo_output(Detector_Quad_demo_output > 0) = 1;
%% Combine bits
Combined_bits = [Detector_In_phase_output; Detector_Quad_demo_output];
Combined_bits = Combined_bits(:).';
Combined_bits = uint16(Combined_bits(L+1:length(Combined_bits)-L));
%% LPC decoder
try
    synth_speech = LPC_tx_s(Combined_bits.');
catch 
    disp("Wrong LPC");
    synth_speech = 0;
end
soundsc(synth_speech, 8000);
end